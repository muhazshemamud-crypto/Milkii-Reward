require("dotenv").config();
const express = require("express");
const http = require("http");
const cors = require("cors");
const crypto = require("crypto");
const { Server } = require("socket.io");
const { createClient } = require("@supabase/supabase-js");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false }
});

app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.static("public"));

app.get("/api/config", (_req,res) => {
  res.json({
    supabaseUrl: process.env.SUPABASE_URL || "",
    supabaseAnonKey: process.env.SUPABASE_ANON_KEY || ""
  });
});

async function authUser(req,res,next){
  try {
    const h=req.headers.authorization||"";
    if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Login barbaada."});
    const token=h.slice(7);
    const {data,error}=await supabase.auth.getUser(token);
    if(error || !data.user) return res.status(401).json({error:"Session sirrii miti."});
    req.user=data.user; req.token=token; next();
  } catch(e){ res.status(401).json({error:"Authentication failed."}); }
}

app.get("/api/messages/:otherUserId", authUser, async (req,res)=>{
  const me=req.user.id, other=req.params.otherUserId;
  const {data,error}=await supabase.from("messages").select("*")
    .or(`and(sender_id.eq.${me},receiver_id.eq.${other}),and(sender_id.eq.${other},receiver_id.eq.${me})`)
    .order("created_at",{ascending:true}).limit(500);
  if(error) return res.status(500).json({error:error.message});
  res.json({messages:data||[]});
});

app.post("/api/pay/chapa", authUser, async (req,res)=>{
  try{
    const amount=Number(req.body.amount);
    if(!Number.isFinite(amount)||amount<=0) return res.status(400).json({error:"Amount sirrii miti."});
    const tx_ref="MC-"+Date.now()+"-"+crypto.randomBytes(4).toString("hex");
    const origin=process.env.APP_URL || `${req.protocol}://${req.get("host")}`;
    const u=req.user;
    const name=(u.user_metadata?.display_name||"Customer").trim().split(/\s+/);
    const payload={
      amount:String(amount),currency:"ETB",
      email:u.email,
      first_name:name[0]||"Customer",last_name:name.slice(1).join(" ")||"User",
      tx_ref,
      callback_url:`${origin}/api/pay/chapa/callback`,
      return_url:`${origin}/?payment=${encodeURIComponent(tx_ref)}`,
      customization:{title:"Telegram Clone",description:req.body.description||"App payment"},
      meta:{user_id:u.id}
    };
    const r=await fetch("https://api.chapa.co/v1/transaction/initialize",{
      method:"POST",
      headers:{"Authorization":`Bearer ${process.env.CHAPA_SECRET_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify(payload)
    });
    const data=await r.json();
    if(!r.ok || data.status!=="success") return res.status(400).json({error:data.message||"Chapa payment failed",data});
    await supabase.from("payments").insert({
      user_id:u.id,tx_ref,amount,currency:"ETB",status:"pending"
    });
    res.json({checkout_url:data.data?.checkout_url,tx_ref});
  }catch(e){res.status(500).json({error:e.message});}
});

async function verifyChapa(tx_ref){
  const r=await fetch(`https://api.chapa.co/v1/transaction/verify/${encodeURIComponent(tx_ref)}`,{
    headers:{"Authorization":`Bearer ${process.env.CHAPA_SECRET_KEY}`}
  });
  const data=await r.json();
  if(r.ok && data.status==="success") {
    const d=data.data||{};
    await supabase.from("payments").update({
      status:d.status||"success",ref_id:d.ref_id||null,verified_at:new Date().toISOString()
    }).eq("tx_ref",tx_ref);
  }
  return data;
}

app.get("/api/pay/chapa/callback", async (req,res)=>{
  try{
    const tx_ref=req.query.trx_ref||req.query.tx_ref;
    if(!tx_ref) return res.status(400).send("Missing transaction reference");
    const result=await verifyChapa(tx_ref);
    res.redirect(`${process.env.APP_URL || ""}/?payment=${encodeURIComponent(tx_ref)}&status=${encodeURIComponent(result?.data?.status||result?.status||"unknown")}`);
  }catch(e){res.status(500).send("Payment verification failed");}
});

app.post("/api/pay/chapa/webhook", async (req,res)=>{
  try{
    const secret=process.env.CHAPA_WEBHOOK_SECRET||"";
    const raw=JSON.stringify(req.body);
    const expected=crypto.createHmac("sha256",secret).update(raw).digest("hex");
    const sig=(req.headers["x-chapa-signature"]||req.headers["chapa-signature"]||"");
    if(!secret || !sig || !crypto.timingSafeEqual(Buffer.from(String(sig)),Buffer.from(expected))){
      return res.status(401).send("invalid signature");
    }
    const tx_ref=req.body.tx_ref;
    if(tx_ref) await verifyChapa(tx_ref);
    res.sendStatus(200);
  }catch(e){res.status(500).send("webhook error");}
});

io.use(async(socket,next)=>{
  try{
    const token=socket.handshake.auth?.token;
    if(!token) return next(new Error("unauthorized"));
    const {data,error}=await supabase.auth.getUser(token);
    if(error||!data.user) return next(new Error("unauthorized"));
    socket.user=data.user; next();
  }catch(e){next(new Error("unauthorized"));}
});

io.on("connection",(socket)=>{
  socket.join(socket.user.id);
  socket.on("send_message",async(data)=>{
    try{
      const receiver_id=String(data.receiver_id||"");
      const content=String(data.content||"").trim();
      if(!receiver_id||!content) return;
      const row={
        sender_id:socket.user.id,receiver_id,content,
        type:data.type||"text"
      };
      const {data:created,error}=await supabase.from("messages").insert(row).select().single();
      if(error) return socket.emit("message_error",{error:error.message});
      io.to(receiver_id).emit("new_message",created);
      socket.emit("message_sent",created);
    }catch(e){socket.emit("message_error",{error:e.message});}
  });
});

const PORT=process.env.PORT||5000;
server.listen(PORT,()=>console.log(`Server running on ${PORT}`));
